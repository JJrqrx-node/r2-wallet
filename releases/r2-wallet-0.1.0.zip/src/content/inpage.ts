// Injected into the page's main world via content-script.ts.
// Creates window.rsquared — the R2 Wallet dApp provider.
// All methods return Promises that resolve when the user approves (or rejects)
// in the extension popup.

import { INPAGE_SOURCE, CONTENT_SOURCE } from "../lib/dapp-bridge";
import type { ContentResponse } from "../lib/dapp-bridge";

// Pending request callbacks, keyed by request ID.
const pending = new Map<
  string,
  { resolve: (v: unknown) => void; reject: (r: string) => void }
>();

let requestCounter = 0;

function nextId(): string {
  return `r2-${Date.now()}-${++requestCounter}`;
}

// Send a request to the content-script and return a Promise.
function request(method: string, params?: unknown): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const id = nextId();
    pending.set(id, { resolve, reject });
    window.postMessage(
      { source: INPAGE_SOURCE, id, method, params } satisfies {
        source: typeof INPAGE_SOURCE;
        id: string;
        method: string;
        params?: unknown;
      },
      "*"
    );
  });
}

// Receive responses from the content-script.
window.addEventListener("message", (event: MessageEvent) => {
  if (event.source !== window) return;
  const data = event.data as ContentResponse;
  if (!data || data.source !== CONTENT_SOURCE) return;
  const entry = pending.get(data.id);
  if (!entry) return;
  pending.delete(data.id);
  if (data.error) {
    entry.reject(data.error);
  } else {
    entry.resolve(data.result);
  }
});

// --- window.rsquared provider ---------------------------------------------

interface R2WalletProvider {
  isR2Wallet: true;
  requestAccounts(): Promise<{ accountName: string; activePubKey: string }>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  signTransaction(txEnvelope: unknown): Promise<any>;
  getBalance(asset: string): Promise<{ balance: string }>;
  getAccount(name: string): Promise<unknown>;
}

const provider: R2WalletProvider = {
  isR2Wallet: true,

  requestAccounts(): Promise<{ accountName: string; activePubKey: string }> {
    return request("requestAccounts") as Promise<{
      accountName: string;
      activePubKey: string;
    }>;
  },

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  signTransaction(txEnvelope: unknown): Promise<any> {
    return request("signTransaction", { txEnvelope });
  },

  getBalance(asset: string): Promise<{ balance: string }> {
    return request("getBalance", { asset }) as Promise<{ balance: string }>;
  },

  getAccount(name: string): Promise<unknown> {
    return request("getAccount", { name });
  },
};

// Freeze to prevent dApp tampering.
Object.freeze(provider);

// Assign to window — use defineProperty to prevent overwriting.
Object.defineProperty(window, "rsquared", {
  value: provider,
  writable: false,
  configurable: false,
});
